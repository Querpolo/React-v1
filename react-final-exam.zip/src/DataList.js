import React from "react";
import Users from "./mock-data";
import Info from "./DataItem";

function App() {
  return (
    <div style={{ margin: "40px" }}>
      <h1 style={{ color: "green" }}> Date Importante</h1>

      {Users.map((e) => {
        return <Info name={e.name} rollNo={e.rollNo} hired={e.hired} />;
      })}
    </div>
  );
}
export default App;
