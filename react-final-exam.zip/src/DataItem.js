import React from "react";

function Info(props) {
  return (
    <div style={{ border: "1px solid black", margin: "10px", width: "20%" }}>
      <p> Name: {props.name} </p>

      <p> ID: {props.rollNo}</p>

      <p>Hired: {props.hired}</p>
    </div>
  );
}
export default Info;
