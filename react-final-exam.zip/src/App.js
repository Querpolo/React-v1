import React, { Component } from "react";
import { BrowserRouter as Router, Switch, Route, Link } from "react-router-dom";
import Home from "./home";
import Query from "./query";
import DataList from "./DataList";
import Info from "./DataList";


class App extends Component {
  render() {
    return (
      <Router>
        <div>
          <h2>React Exam </h2>
          <nav className="navbar navbar-expand-lg navbar-light bg-light">
            <ul className="navbar-nav mr-auto">
              <li>
                <Link to={"/"} className="nav-link">
                  {" "}
                  Home{" "}
                </Link>
              </li>
              <li>
                <Link to={"/DataList"} className="nav-link">
                  DataList
                </Link>
              </li>
              <li>
                <Link to={"/Query"} className="nav-link">
                  Query
                </Link>
              </li>
            </ul>
          </nav>
          <hr />
          <Switch>
            <Route exact path="/" component={Home} />
            <Route path="/DataList" component={DataList} />
            <Route path="/Query" component={Query} />
          </Switch>
        </div>
      </Router>
    );
  }
}

export default App;
