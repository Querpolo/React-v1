import "./styles.css";
import { useState } from "react";
import axios from "axios";

function SearchForm(props) {
  // Initialize component state
  const [name, setname] = useState("");

  const handleChange = (event) => {
    setname(event.target.value);
  };

  const handleSubmit = (event) => {
    event.preventDefault();

    const query = `https://pokeapi.co/api/v2/pokemon/${name}/`;
    axios.get(query).then((response) => {
      console.log(response.data);
      props.onSubmit(response.data);
    });
  };

  return (
    <form onSubmit={handleSubmit}>
      <input
        value={name}
        onChange={handleChange}
        type="text"
        placeholder="Input Pokemon"
        required
      />
      <input type="submit" value="Search for Pokemon" />
    </form>
  );
}

function UserData(props) {
  if (typeof props.name === "undefined") {
    return <h2>No user information</h2>;
  }
  return (
    <div>
      <h2>Name: {props.name}</h2>
      <h2>ID: {props.id}</h2>
      <h2>Height: {props.height} feet</h2>
      <img src={props.sprites.front_default} alt="avatar" wnameth="200" />
    </div>
  );
}

export default function App() {
  const [userObject, setUserObject] = useState({});
  const updateUser = (user) => {
    setUserObject(user);
  };

  return (
    <div className="App">
      <SearchForm onSubmit={updateUser} />
      <UserData {...userObject} />
    </div>
  );
}
