const Users = [
  {
    name: "Deepak",
    rollNo: "123",
    hired: "No"
  },
  {
    name: "Yash",
    rollNo: "124",
    hired: "No"
  },
  {
    name: "Raj",
    rollNo: "125",
    hired: "No"
  },
  {
    name: "Rohan",
    rollNo: "126",
    hired: "Yes"
  },
  {
    name: "Puneet",
    rollNo: "127",
    hired: "Yes"
  },
  {
    name: "Vivek",
    rollNo: "128",
    hired: "Yes"
  },
  {
    name: "Aman",
    rollNo: "129",
    hired: "Yes"
  }
];
export default Users;
